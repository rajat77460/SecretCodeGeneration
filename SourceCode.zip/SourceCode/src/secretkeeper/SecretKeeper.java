/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package secretkeeper;

import View.LoadingScreen;

/**
 *
 * @author _rajat_
 */
public class SecretKeeper {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new  LoadingScreen().setVisible(true);
    }
    
}
